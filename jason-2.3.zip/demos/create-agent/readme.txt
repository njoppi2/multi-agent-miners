This demo shows how an agent can create another agent, see ag1.asl and mylib/my_create_ag.java.

Both, the internal action .create_agent and a new custom internal action are illustrated.
